"use client";
import * as React from "react";
import { FloatingBg } from "@/components/dashboard/floating-bg";
import { Topbar } from "@/components/dashboard/topbar";
import { KpiCards } from "@/components/dashboard/kpi-cards";
import { RevenueChart } from "@/components/dashboard/revenue-chart";
import { SalesBarChart } from "@/components/dashboard/sales-bar-chart";
import { ProductDonut } from "@/components/dashboard/product-donut";
import { SalesFunnel } from "@/components/dashboard/sales-funnel";
import { Leaderboard } from "@/components/dashboard/leaderboard";
import { Transactions } from "@/components/dashboard/transactions";
import { WorldMap } from "@/components/dashboard/world-map";
import { Goals } from "@/components/dashboard/goals";
import { CalendarWidget } from "@/components/dashboard/calendar";
import { Notifications } from "@/components/dashboard/notifications";

export function DashboardShell() {
  return (
    <>
      <FloatingBg />
      <main className="mx-auto max-w-[1440px] px-4 pb-16 sm:px-6 lg:px-8">
        <Topbar />

        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="kicker">Executive overview · Q4 2025</p>
            <h1 className="mt-1 font-display text-2xl font-semibold tracking-tight sm:text-3xl">
              Sales performance
            </h1>
          </div>
          <p className="text-xs text-ink-muted">Updated moments ago · All figures illustrative</p>
        </div>

        <section className="mb-6"><KpiCards /></section>

        <section className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2"><RevenueChart /></div>
          <div><ProductDonut /></div>
        </section>

        <section className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
          <SalesBarChart />
          <SalesFunnel />
        </section>

        <section className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2"><Transactions /></div>
          <div><Leaderboard /></div>
        </section>

        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2"><WorldMap /></div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-1">
            <Goals />
            <Notifications />
          </div>
        </section>

        <section className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-1"><CalendarWidget /></div>
          <div className="hidden lg:col-span-2 lg:block" />
        </section>
      </main>
    </>
  );
}
