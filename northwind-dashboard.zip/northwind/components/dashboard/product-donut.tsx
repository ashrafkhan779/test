"use client";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { GlassTooltip } from "./chart-tooltip";
import { ClientOnly, ChartSkeleton } from "@/components/ui/client-only";
import { revenueByProduct } from "@/lib/data";
import { fmtCurrency } from "@/lib/utils";

export function ProductDonut() {
  const total = revenueByProduct.reduce((a, b) => a + b.value, 0);
  return (
    <Animated>
      <Card className="h-full">
        <CardHeader>
          <div>
            <CardTitle>Revenue by product</CardTitle>
            <CardDescription>Share of total recognized revenue</CardDescription>
          </div>
        </CardHeader>
        <div className="relative h-[210px]">
          <ClientOnly fallback={<ChartSkeleton height={210} />}>
            <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Tooltip content={<GlassTooltip fmt="currency" />} />
              <Pie
                data={revenueByProduct}
                dataKey="value"
                nameKey="name"
                innerRadius={62}
                outerRadius={92}
                paddingAngle={3}
                cornerRadius={6}
                stroke="none"
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
              >
                {revenueByProduct.map((d, i) => (
                  <Cell key={i} fill={d.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
            </ClientOnly>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <span className="kicker">Total</span>
            <span className="num font-display text-2xl font-semibold tracking-tight">{fmtCurrency(total)}</span>
          </div>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {revenueByProduct.map((d) => (
            <div key={d.name} className="flex items-center gap-2 text-xs">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: d.color }} />
              <span className="text-ink-muted">{d.name}</span>
              <span className="num ml-auto font-medium">{`${Math.round((d.value / total) * 100)}%`}</span>
            </div>
          ))}
        </div>
      </Card>
    </Animated>
  );
}
