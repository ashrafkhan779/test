"use client";
import { motion } from "framer-motion";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { regions } from "@/lib/data";
import { fmtCurrency } from "@/lib/utils";

// A stylized dotted world silhouette (equirectangular, 100x50 grid).
// Dots are placed only over landmasses so the map reads without a heavy image.
const LAND: [number, number][] = [];
// generate a light dot field, then mask to rough continents
for (let x = 2; x < 100; x += 2.6) {
  for (let y = 6; y < 46; y += 2.6) {
    const inAmericas = (x > 14 && x < 34 && y > 10 && y < 44) || (x > 24 && x < 33 && y > 30 && y < 46);
    const inEurAfr = (x > 44 && x < 58 && y > 8 && y < 24) || (x > 46 && x < 60 && y > 20 && y < 44);
    const inAsia = (x > 58 && x < 86 && y > 8 && y < 30) || (x > 78 && x < 90 && y > 30 && y < 42);
    if (inAmericas || inEurAfr || inAsia) LAND.push([x, y]);
  }
}

export function WorldMap() {
  return (
    <Animated>
      <Card className="h-full">
        <CardHeader>
          <div>
            <CardTitle>Global sales</CardTitle>
            <CardDescription>Revenue distribution by region</CardDescription>
          </div>
        </CardHeader>

        <div className="relative">
          <svg viewBox="0 0 100 50" className="w-full" role="img" aria-label="World sales map">
            {LAND.map(([x, y], i) => (
              <circle key={i} cx={x} cy={y} r={0.5} fill="rgba(255,255,255,0.10)" />
            ))}
            {regions.map((r, i) => (
              <g key={r.code}>
                <motion.circle
                  cx={r.x} cy={r.y} r={2}
                  fill="none" stroke="#6366F1" strokeWidth={0.4}
                  initial={false}
                  animate={{ opacity: [0.6, 0, 0.6], scale: [0.6, 2.4, 0.6] }}
                  transition={{ duration: 3, repeat: Infinity, delay: i * 0.7, ease: "easeOut" }}
                  style={{ transformOrigin: `${r.x}px ${r.y}px` }}
                />
                <circle cx={r.x} cy={r.y} r={1.4} fill="#6366F1" />
                <circle cx={r.x} cy={r.y} r={0.6} fill="#C7D2FE" />
              </g>
            ))}
          </svg>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {regions.map((r) => (
            <div key={r.code} className="rounded-xl border border-glass-border bg-white/[0.02] p-2.5">
              <p className="kicker">{r.code}</p>
              <p className="num mt-0.5 font-display text-sm font-semibold">{fmtCurrency(r.value)}</p>
              <p className="text-[11px] text-ink-muted">{`${r.share}% of total`}</p>
            </div>
          ))}
        </div>
      </Card>
    </Animated>
  );
}
