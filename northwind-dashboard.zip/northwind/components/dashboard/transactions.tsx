"use client";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { transactions } from "@/lib/data";
import { fmtCurrency } from "@/lib/utils";

const statusTone = { Paid: "up", Pending: "amber", Refunded: "down" } as const;

export function Transactions() {
  return (
    <Animated>
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Recent transactions</CardTitle>
            <CardDescription>Latest closed and pending deals</CardDescription>
          </div>
          <Button variant="ghost" size="sm">View all <ArrowUpRight className="h-3.5 w-3.5" /></Button>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-glass-border text-left">
                {["Transaction", "Client", "Product", "Amount", "Status", "Date"].map((h) => (
                  <th key={h} className="kicker pb-2 pr-4 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {transactions.map((t, i) => (
                <motion.tr
                  key={t.id}
                  initial={false}
                  animate={{ opacity: [0, 1] }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  className="group border-b border-glass-border/60 transition-colors last:border-0 hover:bg-white/[0.03]"
                >
                  <td className="num py-3 pr-4 font-mono text-xs text-ink-muted">{t.id}</td>
                  <td className="py-3 pr-4 font-medium">{t.client}</td>
                  <td className="py-3 pr-4 text-ink-muted">{t.product}</td>
                  <td className="num py-3 pr-4 font-semibold">{fmtCurrency(t.amount)}</td>
                  <td className="py-3 pr-4">
                    <Badge tone={statusTone[t.status as keyof typeof statusTone]}>{t.status}</Badge>
                  </td>
                  <td className="py-3 pr-4 text-ink-muted">{t.date}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </Animated>
  );
}
