"use client";
import { motion } from "framer-motion";
import { Trophy, Flag, AlertTriangle, Info, Bell } from "lucide-react";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { notifications } from "@/lib/data";

const config = {
  win: { Icon: Trophy, color: "#2DD4BF" },
  goal: { Icon: Flag, color: "#6366F1" },
  alert: { Icon: AlertTriangle, color: "#F0B429" },
  info: { Icon: Info, color: "#8A90A2" },
} as const;

export function Notifications() {
  return (
    <Animated>
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Signals from across the pipeline</CardDescription>
          </div>
          <span className="relative">
            <Bell className="h-4 w-4 text-ink-muted" />
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-accent-rose ring-2 ring-base-800" />
          </span>
        </CardHeader>
        <div className="space-y-1">
          {notifications.map((n, i) => {
            const { Icon, color } = config[n.type as keyof typeof config];
            return (
              <motion.div
                key={i}
                initial={false}
                animate={{ opacity: [0, 1], x: [8, 0] }}
                transition={{ duration: 0.5, delay: i * 0.07 }}
                className="flex items-start gap-3 rounded-xl p-2 transition-colors hover:bg-white/[0.03]"
              >
                <div
                  className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg ring-1 ring-white/10"
                  style={{ background: `${color}1f` }}
                >
                  <Icon className="h-4 w-4" style={{ color }} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium leading-tight">{n.title}</p>
                  <p className="truncate text-xs text-ink-muted">{n.detail}</p>
                </div>
                <span className="shrink-0 text-[10px] text-ink-muted">{n.time}</span>
              </motion.div>
            );
          })}
        </div>
      </Card>
    </Animated>
  );
}
