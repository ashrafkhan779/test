"use client";
import { Target } from "lucide-react";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { goals } from "@/lib/data";
import { fmtCurrency, fmtNumber, fmtPct } from "@/lib/utils";

function fmt(unit: string, n: number) {
  if (unit === "currency") return fmtCurrency(n);
  if (unit === "percent") return fmtPct(n, 0);
  return fmtNumber(n);
}

export function Goals() {
  return (
    <Animated>
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Goal progress</CardTitle>
            <CardDescription>Tracking toward annual targets</CardDescription>
          </div>
          <Target className="h-4 w-4 text-accent-teal" />
        </CardHeader>
        <div className="space-y-4">
          {goals.map((g, i) => {
            const pct = Math.min(100, (g.current / g.target) * 100);
            return (
              <div key={g.label}>
                <div className="mb-1.5 flex items-center justify-between text-xs">
                  <span className="text-ink-muted">{g.label}</span>
                  <span className="num font-medium">
                    <span>{fmt(g.unit, g.current)}</span> <span className="text-ink-muted">{`/ ${fmt(g.unit, g.target)}`}</span>
                  </span>
                </div>
                <Progress
                  value={pct}
                  delay={i * 0.1}
                  barClassName={pct >= 95 ? "from-accent-teal to-accent-sky" : "from-accent-indigo to-accent-violet"}
                />
                <p className="mt-1 text-right text-[11px] text-ink-muted">{`${pct.toFixed(0)}% complete`}</p>
              </div>
            );
          })}
        </div>
      </Card>
    </Animated>
  );
}
