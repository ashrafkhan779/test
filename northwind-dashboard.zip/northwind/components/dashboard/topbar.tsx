"use client";
import { Search, Command, Bell, Settings2, ChevronDown, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { motion } from "framer-motion";

export function Topbar() {
  return (
    <motion.header
      initial={false}
      animate={{ opacity: [0, 1], y: [-12, 0] }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="glass-strong sticky top-4 z-20 mb-6 flex items-center gap-4 px-4 py-3"
    >
      <div className="flex items-center gap-2.5 pr-2">
        <div className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-accent-indigo to-accent-violet shadow-glow">
          <Sparkles className="h-4 w-4 text-white" />
        </div>
        <div className="leading-tight">
          <p className="font-display text-sm font-semibold tracking-tight">Northwind</p>
          <p className="text-[10px] uppercase tracking-[0.16em] text-ink-muted">Sales command</p>
        </div>
      </div>

      <div className="ml-2 hidden flex-1 items-center gap-2 rounded-xl border border-glass-border bg-white/[0.03] px-3 py-2 md:flex">
        <Search className="h-4 w-4 text-ink-muted" />
        <input
          placeholder="Search deals, accounts, agents…"
          className="w-full bg-transparent text-sm text-ink placeholder:text-ink-muted focus:outline-none"
        />
        <kbd className="flex items-center gap-1 rounded-md border border-glass-border px-1.5 py-0.5 text-[10px] text-ink-muted">
          <Command className="h-3 w-3" /> K
        </kbd>
      </div>

      <div className="ml-auto flex items-center gap-2">
        <Button variant="ghost" size="icon" aria-label="Notifications"><Bell className="h-4 w-4" /></Button>
        <Button variant="ghost" size="icon" aria-label="Settings"><Settings2 className="h-4 w-4" /></Button>
        <div className="mx-1 h-6 w-px bg-glass-border" />
        <button className="flex items-center gap-2 rounded-xl border border-glass-border bg-white/[0.03] py-1 pl-1 pr-2 transition-colors hover:bg-white/[0.06]">
          <Avatar initials="EV" className="h-7 w-7" />
          <span className="hidden text-xs font-medium sm:block">Elena Voss</span>
          <ChevronDown className="h-3.5 w-3.5 text-ink-muted" />
        </button>
      </div>
    </motion.header>
  );
}
