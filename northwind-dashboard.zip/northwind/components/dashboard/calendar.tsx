"use client";
import { CalendarDays } from "lucide-react";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { events } from "@/lib/data";

const DAYS = ["S", "M", "T", "W", "T", "F", "S"];
// December 2025 starts on a Monday (offset 1)
const OFFSET = 1;
const DAYS_IN_MONTH = 31;
const TODAY = 15;

export function CalendarWidget() {
  const eventDays = new Map(events.map((e) => [e.day, e.label]));
  const cells: (number | null)[] = [
    ...Array(OFFSET).fill(null),
    ...Array.from({ length: DAYS_IN_MONTH }, (_, i) => i + 1),
  ];

  return (
    <Animated>
      <Card>
        <CardHeader>
          <div>
            <CardTitle>December 2025</CardTitle>
            <CardDescription>Upcoming reviews and milestones</CardDescription>
          </div>
          <CalendarDays className="h-4 w-4 text-accent-indigo" />
        </CardHeader>
        <div className="grid grid-cols-7 gap-1 text-center">
          {DAYS.map((d, i) => (
            <div key={i} className="pb-1 text-[10px] font-medium text-ink-muted">{d}</div>
          ))}
          {cells.map((day, i) => {
            if (day === null) return <div key={i} />;
            const isToday = day === TODAY;
            const hasEvent = eventDays.has(day);
            return (
              <div
                key={i}
                title={hasEvent ? eventDays.get(day)! : undefined}
                className={[
                  "relative grid aspect-square place-items-center rounded-lg text-xs transition-colors",
                  isToday ? "bg-accent-indigo/90 font-semibold text-white shadow-glow" : "text-ink hover:bg-white/[0.05]",
                  hasEvent && !isToday ? "text-ink" : "",
                ].join(" ")}
              >
                {day}
                {hasEvent && !isToday && (
                  <span className="absolute bottom-1 h-1 w-1 rounded-full bg-accent-teal" />
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-3 space-y-1.5 border-t border-glass-border pt-3">
          {events.map((e) => (
            <div key={e.day} className="flex items-center gap-2 text-xs">
              <span className="grid h-6 w-6 place-items-center rounded-md bg-white/[0.05] text-[10px] font-semibold">
                {e.day}
              </span>
              <span className="text-ink-muted">{e.label}</span>
            </div>
          ))}
        </div>
      </Card>
    </Animated>
  );
}
