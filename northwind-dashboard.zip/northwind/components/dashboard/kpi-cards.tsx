"use client";
import { motion } from "framer-motion";
import { Area, AreaChart, ResponsiveContainer, YAxis } from "recharts";
import { ArrowUpRight, ArrowDownRight, DollarSign, ShoppingCart, Target, UserPlus } from "lucide-react";
import { CountUp } from "@/components/ui/motion";
import { Badge } from "@/components/ui/badge";
import { kpis } from "@/lib/data";
import { ClientOnly } from "@/components/ui/client-only";
import { fmtCurrency, fmtNumber, fmtPct, cn } from "@/lib/utils";

const icons = { revenue: DollarSign, sales: ShoppingCart, conversion: Target, leads: UserPlus } as const;
const accents = {
  revenue: "#6366F1", sales: "#2DD4BF", conversion: "#8B5CF6", leads: "#38BDF8",
} as const;

function formatValue(unit: string, n: number) {
  if (unit === "currency") return fmtCurrency(n);
  if (unit === "percent") return fmtPct(n);
  return fmtNumber(n);
}

export function KpiCards() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {kpis.map((k, i) => {
        const Icon = icons[k.key];
        const accent = accents[k.key];
        const up = k.delta >= 0;
        const sparkData = k.spark.map((v, idx) => ({ i: idx, v }));
        return (
          <motion.div
            key={k.key}
            initial={false}
            animate={{ opacity: [0, 1], y: [16, 0] }}
            transition={{ duration: 0.6, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ y: -4 }}
            className="group glass relative overflow-hidden p-5"
          >
            {/* glow wash on hover */}
            <div
              className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100"
              style={{ background: `radial-gradient(circle, ${accent}44, transparent 70%)` }}
            />
            <div className="mb-4 flex items-center justify-between">
              <div
                className="grid h-10 w-10 place-items-center rounded-xl ring-1 ring-white/10"
                style={{ background: `linear-gradient(135deg, ${accent}33, ${accent}11)` }}
              >
                <Icon className="h-[18px] w-[18px]" style={{ color: accent }} />
              </div>
              <Badge tone={up ? "up" : "down"}>
                {up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                {fmtPct(Math.abs(k.delta))}
              </Badge>
            </div>

            <p className="kicker">{k.label}</p>
            <div className="mt-1 font-display text-[28px] font-semibold leading-none tracking-tight">
              <CountUp value={k.value} format={(n) => formatValue(k.unit, n)} />
            </div>
            <p className="mt-1.5 text-xs text-ink-muted">{k.caption}</p>

            {/* sparkline draws in on mount */}
            <div className="mt-3 h-12">
              <ClientOnly fallback={<div className="h-full w-full" />}>
                <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sparkData} margin={{ top: 4, bottom: 0, left: 0, right: 0 }}>
                  <defs>
                    <linearGradient id={`spark-${k.key}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={accent} stopOpacity={0.5} />
                      <stop offset="100%" stopColor={accent} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <YAxis hide domain={["dataMin - 4", "dataMax + 4"]} />
                  <Area
                    type="monotone"
                    dataKey="v"
                    stroke={accent}
                    strokeWidth={2}
                    fill={`url(#spark-${k.key})`}
                    isAnimationActive
                    animationDuration={1400}
                    animationEasing="ease-out"
                    dot={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
              </ClientOnly>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
