"use client";
import { motion } from "framer-motion";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { funnel } from "@/lib/data";
import { fmtNumber } from "@/lib/utils";

const shades = ["#6366F1", "#6D62F0", "#7B5FE4", "#8B5CF6", "#9B6BEA", "#2DD4BF"];

export function SalesFunnel() {
  const top = funnel[0].value;
  return (
    <Animated>
      <Card className="h-full">
        <CardHeader>
          <div>
            <CardTitle>Sales funnel</CardTitle>
            <CardDescription>Stage-by-stage conversion</CardDescription>
          </div>
        </CardHeader>
        <div className="space-y-2.5">
          {funnel.map((s, i) => {
            const pct = (s.value / top) * 100;
            const conv = i === 0 ? 100 : (s.value / funnel[i - 1].value) * 100;
            return (
              <div key={s.stage}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-ink-muted">{s.stage}</span>
                  <span className="num font-medium">
                    <span>{fmtNumber(s.value)}</span>
                    {i > 0 && <span className="ml-2 text-ink-muted">{`${conv.toFixed(0)}%`}</span>}
                  </span>
                </div>
                <div className="h-7 w-full overflow-hidden rounded-lg bg-white/[0.04]">
                  <motion.div
                    className="flex h-full items-center rounded-lg"
                    style={{ background: `linear-gradient(90deg, ${shades[i]}, ${shades[i]}99)` }}
                    initial={false}
                    animate={{ width: ["0%", `${pct}%`] }}
                    transition={{ duration: 1, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </Animated>
  );
}
