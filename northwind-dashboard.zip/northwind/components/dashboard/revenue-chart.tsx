"use client";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Line,
} from "recharts";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GlassTooltip } from "./chart-tooltip";
import { ClientOnly, ChartSkeleton } from "@/components/ui/client-only";
import { revenueSeries } from "@/lib/data";
import { fmtCurrency, fmtAxis } from "@/lib/utils";

export function RevenueChart() {
  return (
    <Animated>
      <Card className="h-full">
        <CardHeader>
          <div>
            <CardTitle>Revenue trajectory</CardTitle>
            <CardDescription>Monthly recognized revenue against target</CardDescription>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-[11px] text-ink-muted">
              <span className="h-2 w-2 rounded-full bg-accent-indigo" /> Revenue
            </span>
            <span className="flex items-center gap-1.5 text-[11px] text-ink-muted">
              <span className="h-2 w-4 rounded-full border-t border-dashed border-ink-muted" /> Target
            </span>
          </div>
        </CardHeader>
        <div className="h-[280px] w-full">
          <ClientOnly fallback={<ChartSkeleton height={280} />}>
            <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={revenueSeries} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
              <defs>
                <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366F1" stopOpacity={0.42} />
                  <stop offset="100%" stopColor="#6366F1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} dy={8} />
              <YAxis
                tickLine={false}
                axisLine={false}
                width={48}
                tickMargin={6}
                tickFormatter={(v) => fmtAxis(v)}
              />
              <Tooltip content={<GlassTooltip fmt="currency" />} cursor={{ stroke: "rgba(255,255,255,0.14)" }} />
              <Area
                type="monotone" name="Revenue" dataKey="revenue" stroke="#6366F1" strokeWidth={2.5}
                fill="url(#revFill)" isAnimationActive animationDuration={1600} animationEasing="ease-out"
                dot={false} activeDot={{ r: 4, strokeWidth: 0, fill: "#6366F1" }}
              />
              <Line
                type="monotone" name="Target" dataKey="target" stroke="#8A90A2" strokeWidth={1.5}
                strokeDasharray="5 5" dot={false} isAnimationActive animationDuration={1600}
              />
            </AreaChart>
          </ResponsiveContainer>
            </ClientOnly>
        </div>
      </Card>
    </Animated>
  );
}
