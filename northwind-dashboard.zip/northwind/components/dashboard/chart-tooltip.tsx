"use client";
import { fmtCurrency, fmtNumber } from "@/lib/utils";

type Fmt = "currency" | "number";

export function GlassTooltip({
  active,
  payload,
  label,
  fmt = "number",
}: {
  active?: boolean;
  payload?: any[];
  label?: string;
  fmt?: Fmt;
}) {
  if (!active || !payload?.length) return null;
  const f = fmt === "currency" ? fmtCurrency : fmtNumber;
  return (
    <div className="glass-strong rounded-xl px-3 py-2 text-xs">
      {label && <p className="mb-1 font-medium text-ink">{label}</p>}
      <div className="space-y-0.5">
        {payload.map((p, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full" style={{ background: p.color || p.stroke || p.fill }} />
            <span className="text-ink-muted">{p.name}</span>
            <span className="num ml-auto font-medium text-ink">{f(p.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
