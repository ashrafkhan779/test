"use client";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { GlassTooltip } from "./chart-tooltip";
import { ClientOnly, ChartSkeleton } from "@/components/ui/client-only";
import { monthlySales } from "@/lib/data";

export function SalesBarChart() {
  const max = Math.max(...monthlySales.map((d) => d.sales));
  return (
    <Animated delay={0.05}>
      <Card className="h-full">
        <CardHeader>
          <div>
            <CardTitle>Monthly sales</CardTitle>
            <CardDescription>Closed-won deals per month</CardDescription>
          </div>
        </CardHeader>
        <div className="h-[280px] w-full">
          <ClientOnly fallback={<ChartSkeleton height={280} />}>
            <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlySales} margin={{ top: 8, right: 8, left: -14, bottom: 0 }}>
              <defs>
                <linearGradient id="barFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2DD4BF" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#2DD4BF" stopOpacity={0.35} />
                </linearGradient>
                <linearGradient id="barFillTop" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0.4} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} dy={8} />
              <YAxis tickLine={false} axisLine={false} width={40} />
              <Tooltip content={<GlassTooltip fmt="number" />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
              <Bar dataKey="sales" name="Sales" radius={[6, 6, 0, 0]} isAnimationActive animationDuration={1200} animationEasing="ease-out">
                {monthlySales.map((d, i) => (
                  <Cell key={i} fill={d.sales === max ? "url(#barFillTop)" : "url(#barFill)"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
            </ClientOnly>
        </div>
      </Card>
    </Animated>
  );
}
