"use client";
import { motion } from "framer-motion";

// subtle floating orbs behind the glass — very low alpha, no neon
const orbs = [
  { size: 460, x: "6%", y: "10%", from: "rgba(99,102,241,0.22)", dur: 16 },
  { size: 380, x: "72%", y: "2%", from: "rgba(139,92,246,0.18)", dur: 20 },
  { size: 420, x: "58%", y: "68%", from: "rgba(45,212,191,0.14)", dur: 18 },
  { size: 300, x: "16%", y: "74%", from: "rgba(56,189,248,0.12)", dur: 22 },
];

export function FloatingBg() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-[1] overflow-hidden">
      {orbs.map((o, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full blur-[80px]"
          style={{
            width: o.size,
            height: o.size,
            left: o.x,
            top: o.y,
            background: `radial-gradient(circle at 30% 30%, ${o.from}, transparent 70%)`,
          }}
          animate={{ y: [0, -26, 0], x: [0, 14, 0] }}
          transition={{ duration: o.dur, repeat: Infinity, ease: "easeInOut", delay: i * 1.4 }}
        />
      ))}
    </div>
  );
}
