"use client";
import { motion } from "framer-motion";
import { Trophy, Medal } from "lucide-react";
import { Animated } from "@/components/ui/animated";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { agents } from "@/lib/data";
import { fmtCurrency } from "@/lib/utils";

export function Leaderboard() {
  return (
    <Animated>
      <Card className="h-full">
        <CardHeader>
          <div>
            <CardTitle>Agent leaderboard</CardTitle>
            <CardDescription>Ranked by revenue this quarter</CardDescription>
          </div>
          <Trophy className="h-4 w-4 text-accent-amber" />
        </CardHeader>
        <div className="space-y-3">
          {agents.map((a, i) => (
            <motion.div
              key={a.name}
              initial={false}
              animate={{ opacity: [0, 1], x: [-8, 0] }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="flex items-center gap-3 rounded-xl px-2 py-1.5 transition-colors hover:bg-white/[0.03]"
            >
              <span className="w-4 text-center text-xs font-semibold text-ink-muted">{i + 1}</span>
              <div className="relative">
                <Avatar initials={a.avatar} />
                {i === 0 && (
                  <Medal className="absolute -right-1 -top-1 h-3.5 w-3.5 text-accent-amber" strokeWidth={2.5} />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-medium">{a.name}</p>
                  <span className="num text-sm font-semibold">{fmtCurrency(a.revenue)}</span>
                </div>
                <div className="mt-1 flex items-center gap-2">
                  <Progress value={a.quota} delay={i * 0.06} className="h-1.5 flex-1" />
                  <Badge tone="neutral" className="shrink-0">{a.region}</Badge>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>
    </Animated>
  );
}
