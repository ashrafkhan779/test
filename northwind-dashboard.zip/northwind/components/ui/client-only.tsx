"use client";
import * as React from "react";

// Recharts measures the DOM to size its <ResponsiveContainer>, which makes its
// server output differ from the client's first paint. Gating charts behind a
// mount check renders a stable placeholder on the server and hydrates cleanly.
export function ClientOnly({
  children,
  fallback = null,
}: {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}) {
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);
  if (!mounted) return <>{fallback}</>;
  return <>{children}</>;
}

export function ChartSkeleton({ height = 280 }: { height?: number }) {
  return (
    <div
      className="w-full animate-pulse rounded-xl bg-white/[0.03]"
      style={{ height }}
      aria-hidden
    />
  );
}
