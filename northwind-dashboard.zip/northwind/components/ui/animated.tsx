"use client";
import * as React from "react";
import { motion, type HTMLMotionProps } from "framer-motion";

/**
 * Entrance wrapper that is hydration-safe.
 *
 * The element renders in its FINAL (visible) state during SSR and on the first
 * client paint, so server and client HTML match exactly. A mount effect then
 * plays the entrance from a hidden state -> visible. Because the animation only
 * starts after mount, it never diverges from the server output during hydration.
 */
export function Animated({
  children,
  delay = 0,
  y = 16,
  className,
  ...rest
}: {
  children: React.ReactNode;
  delay?: number;
  y?: number;
  className?: string;
} & Omit<HTMLMotionProps<"div">, "ref">) {
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  return (
    <motion.div
      className={className}
      initial={false}
      animate={mounted ? { opacity: [0, 1], y: [y, 0] } : { opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}
      {...rest}
    >
      {children}
    </motion.div>
  );
}
