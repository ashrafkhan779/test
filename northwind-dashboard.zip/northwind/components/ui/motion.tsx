"use client";
import * as React from "react";
import { motion, useInView, animate } from "framer-motion";
import { cn } from "@/lib/utils";

// staggered reveal container + item
export const reveal = {
  hidden: { opacity: 0, y: 14 },
  show: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.6, ease: [0.16, 1, 0.3, 1] },
  }),
};

export function Reveal({
  children,
  i = 0,
  className,
}: {
  children: React.ReactNode;
  i?: number;
  className?: string;
}) {
  return (
    <motion.div variants={reveal} custom={i} initial="hidden" animate="show" className={className}>
      {children}
    </motion.div>
  );
}

// Animated count-up. Renders the FINAL formatted value on the server and on the
// first client paint (so SSR and hydration match), then animates from 0 → value
// only after mount when scrolled into view. This avoids hydration mismatches.
export function CountUp({
  value,
  format,
  className,
  duration = 1.4,
}: {
  value: number;
  format: (n: number) => string;
  className?: string;
  duration?: number;
}) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [mounted, setMounted] = React.useState(false);
  const [display, setDisplay] = React.useState(() => format(value));

  React.useEffect(() => setMounted(true), []);

  React.useEffect(() => {
    if (!mounted || !inView) return;
    const controls = animate(0, value, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setDisplay(format(v)),
    });
    return () => controls.stop();
  }, [mounted, inView, value, duration, format]);

  return (
    <span ref={ref} className={cn("num", className)}>
      {display}
    </span>
  );
}
