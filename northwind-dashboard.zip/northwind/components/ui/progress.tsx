"use client";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function Progress({
  value,
  className,
  barClassName,
  delay = 0,
}: {
  value: number;
  className?: string;
  barClassName?: string;
  delay?: number;
}) {
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-white/[0.06]", className)}>
      <motion.div
        className={cn("h-full rounded-full bg-gradient-to-r from-accent-indigo to-accent-violet", barClassName)}
        initial={false}
        animate={{ width: ["0%", `${Math.min(100, Math.max(0, value))}%`] }}
        transition={{ duration: 1.1, delay, ease: [0.16, 1, 0.3, 1] }}
      />
    </div>
  );
}
