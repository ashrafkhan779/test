import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium tracking-tight transition-colors",
  {
    variants: {
      tone: {
        neutral: "bg-white/5 text-ink-muted border border-glass-border",
        up: "bg-accent-teal/10 text-accent-teal border border-accent-teal/20",
        down: "bg-accent-rose/10 text-accent-rose border border-accent-rose/20",
        indigo: "bg-accent-indigo/10 text-accent-indigo border border-accent-indigo/20",
        amber: "bg-accent-amber/10 text-accent-amber border border-accent-amber/20",
      },
    },
    defaultVariants: { tone: "neutral" },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, tone, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ tone }), className)} {...props} />;
}
