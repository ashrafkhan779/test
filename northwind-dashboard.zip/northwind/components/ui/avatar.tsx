import { cn } from "@/lib/utils";

export function Avatar({ initials, className }: { initials: string; className?: string }) {
  return (
    <div
      className={cn(
        "grid h-9 w-9 place-items-center rounded-full text-[11px] font-semibold text-white/90",
        "bg-gradient-to-br from-accent-indigo/70 to-accent-violet/70 ring-1 ring-white/10",
        className
      )}
    >
      {initials}
    </div>
  );
}
