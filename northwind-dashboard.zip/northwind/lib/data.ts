// ---------------------------------------------------------------------------
// Mock data for the Northwind executive sales dashboard.
// All figures are illustrative. Swap this module for a real data source
// (API route, RSC fetch, or server action) without touching the components.
// ---------------------------------------------------------------------------

export const kpis = [
  { key: "revenue", label: "Revenue", value: 4_820_400, unit: "currency", delta: 12.4, caption: "vs last quarter",
    spark: [32, 38, 35, 44, 48, 46, 58, 62, 60, 71, 76, 84] },
  { key: "sales", label: "Closed sales", value: 1_284, unit: "number", delta: 8.1, caption: "deals won this quarter",
    spark: [12, 15, 14, 18, 17, 22, 21, 26, 24, 29, 31, 34] },
  { key: "conversion", label: "Conversion", value: 24.8, unit: "percent", delta: 2.3, caption: "lead → close",
    spark: [18, 19, 20, 19, 21, 22, 21, 23, 22, 24, 24, 25] },
  { key: "leads", label: "Qualified leads", value: 9_640, unit: "number", delta: -3.2, caption: "vs last quarter",
    spark: [88, 84, 90, 79, 82, 76, 80, 74, 78, 72, 70, 68] },
] as const;

export const revenueSeries = [
  { month: "Jan", revenue: 286_000, target: 300_000 },
  { month: "Feb", revenue: 312_000, target: 310_000 },
  { month: "Mar", revenue: 298_000, target: 320_000 },
  { month: "Apr", revenue: 356_000, target: 330_000 },
  { month: "May", revenue: 402_000, target: 360_000 },
  { month: "Jun", revenue: 388_000, target: 380_000 },
  { month: "Jul", revenue: 441_000, target: 400_000 },
  { month: "Aug", revenue: 468_000, target: 420_000 },
  { month: "Sep", revenue: 452_000, target: 440_000 },
  { month: "Oct", revenue: 512_000, target: 460_000 },
  { month: "Nov", revenue: 548_000, target: 490_000 },
  { month: "Dec", revenue: 604_000, target: 520_000 },
];

export const monthlySales = [
  { month: "Jan", sales: 82 }, { month: "Feb", sales: 94 }, { month: "Mar", sales: 88 },
  { month: "Apr", sales: 108 }, { month: "May", sales: 124 }, { month: "Jun", sales: 118 },
  { month: "Jul", sales: 136 }, { month: "Aug", sales: 142 }, { month: "Sep", sales: 138 },
  { month: "Oct", sales: 156 }, { month: "Nov", sales: 168 }, { month: "Dec", sales: 184 },
];

export const revenueByProduct = [
  { name: "Platform", value: 2_180_000, color: "#6366F1" },
  { name: "Analytics", value: 1_240_000, color: "#2DD4BF" },
  { name: "Automation", value: 820_000, color: "#8B5CF6" },
  { name: "Support", value: 580_000, color: "#F0B429" },
];

export const funnel = [
  { stage: "Visitors", value: 48_200 },
  { stage: "Leads", value: 21_400 },
  { stage: "Qualified", value: 9_640 },
  { stage: "Proposals", value: 4_120 },
  { stage: "Negotiation", value: 2_180 },
  { stage: "Closed won", value: 1_284 },
];

export const agents = [
  { name: "Amara Okafor", region: "EMEA", revenue: 842_000, deals: 61, quota: 94, avatar: "AO" },
  { name: "Liam Chen", region: "APAC", revenue: 786_000, deals: 58, quota: 88, avatar: "LC" },
  { name: "Sofia Marchetti", region: "EMEA", revenue: 703_000, deals: 49, quota: 81, avatar: "SM" },
  { name: "Noah Bennett", region: "AMER", revenue: 668_000, deals: 52, quota: 77, avatar: "NB" },
  { name: "Priya Nair", region: "APAC", revenue: 611_000, deals: 44, quota: 72, avatar: "PN" },
];

export const transactions = [
  { id: "TXN-90412", client: "Meridian Freight", product: "Platform", amount: 84_500, status: "Paid", date: "Dec 14" },
  { id: "TXN-90408", client: "Halcyon Health", product: "Analytics", amount: 52_200, status: "Pending", date: "Dec 14" },
  { id: "TXN-90401", client: "Vertex Robotics", product: "Automation", amount: 128_000, status: "Paid", date: "Dec 13" },
  { id: "TXN-90396", client: "Cobalt Energy", product: "Platform", amount: 96_800, status: "Paid", date: "Dec 13" },
  { id: "TXN-90390", client: "Juniper Retail", product: "Support", amount: 18_400, status: "Refunded", date: "Dec 12" },
  { id: "TXN-90385", client: "Atlas Logistics", product: "Analytics", amount: 61_900, status: "Pending", date: "Dec 12" },
];

export const regions = [
  { code: "AMER", label: "Americas", value: 2_140_000, share: 44, x: 26, y: 42 },
  { code: "EMEA", label: "Europe & Africa", value: 1_580_000, share: 33, x: 50, y: 38 },
  { code: "APAC", label: "Asia-Pacific", value: 1_100_000, share: 23, x: 78, y: 52 },
];

export const goals = [
  { label: "Annual revenue", current: 4_820_400, target: 6_000_000, unit: "currency" },
  { label: "New logos", current: 184, target: 250, unit: "number" },
  { label: "Net retention", current: 118, target: 120, unit: "percent" },
];

export const notifications = [
  { type: "win", title: "Vertex Robotics closed", detail: "$128,000 · Automation", time: "12m ago" },
  { type: "goal", title: "APAC hit 88% of quota", detail: "Liam Chen · 2 deals from target", time: "1h ago" },
  { type: "alert", title: "Juniper Retail refund", detail: "$18,400 reversed", time: "3h ago" },
  { type: "info", title: "Q4 board review scheduled", detail: "Dec 20 · 10:00 GMT", time: "5h ago" },
];

export const events = [
  { day: 18, label: "Pipeline review" },
  { day: 20, label: "Board review" },
  { day: 23, label: "APAC close" },
  { day: 27, label: "Renewals" },
];
