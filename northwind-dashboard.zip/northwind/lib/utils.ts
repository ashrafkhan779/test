import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ---------------------------------------------------------------------------
// Deterministic formatters.
//
// NB: Intl "compact" notation (e.g. $4.8M) is NOT stable across runtimes — Node's
// ICU renders "$6.0M" while a browser renders "$6M", which breaks React hydration
// (server/client text mismatch). So compact figures are built by hand here to
// guarantee identical output on the server and in the browser.
// ---------------------------------------------------------------------------

function withCommas(n: number, digits = 0) {
  return n.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

function compact(n: number, prefix = ""): string {
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  const trim = (v: number) => {
    // one decimal, but drop a trailing ".0" — applied identically everywhere
    const s = v.toFixed(1);
    return s.endsWith(".0") ? s.slice(0, -2) : s;
  };
  if (abs >= 1_000_000_000) return `${sign}${prefix}${trim(abs / 1_000_000_000)}B`;
  if (abs >= 1_000_000) return `${sign}${prefix}${trim(abs / 1_000_000)}M`;
  if (abs >= 10_000) return `${sign}${prefix}${trim(abs / 1_000)}K`;
  return `${sign}${prefix}${withCommas(abs)}`;
}

// standard currency (e.g. $84,500) — no compaction, always deterministic
export const fmtCurrency = (n: number) =>
  n >= 1_000_000 ? compact(n, "$") : `$${withCommas(Math.round(n))}`;

// always-compact currency for axis ticks and big KPIs (e.g. $300K, $4.8M, $6M)
export const fmtAxis = (n: number) => compact(n, "$");

// numbers: compact above 10k (e.g. 9,640 / 24.8K), else grouped
export const fmtNumber = (n: number) => (n >= 10_000 ? compact(n) : withCommas(Math.round(n)));

export const fmtPct = (n: number, d = 1) => `${n.toFixed(d)}%`;
